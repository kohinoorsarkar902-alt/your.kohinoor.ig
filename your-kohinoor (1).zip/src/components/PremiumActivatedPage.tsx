import React from 'react';
import { motion } from 'motion/react';
import {
  Crown,
  Sparkles,
  CheckCircle2,
  ExternalLink,
  Instagram,
  ShieldCheck,
} from 'lucide-react';
import {
  INSTAGRAM_HANDLE,
  INSTAGRAM_TAGLINE,
  INSTAGRAM_URL,
} from '../types.ts';

interface PremiumActivatedPageProps {
  utrNumber: string;
}

export const PremiumActivatedPage: React.FC<PremiumActivatedPageProps> = ({
  utrNumber,
}) => {
  return (
    <div className="w-full max-w-xl mx-auto px-4 py-8 sm:py-14 flex flex-col items-center justify-center">
      {/* Activated Container Card */}
      <div
        id="premium-activated-card"
        className="w-full relative rounded-3xl bg-[#0e0e13] border border-amber-500/35 p-7 sm:p-10 text-center shadow-2xl shadow-black/90 flex flex-col items-center overflow-hidden"
      >
        {/* Ambient Top Golden Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-amber-400/10 blur-3xl rounded-full pointer-events-none" />

        {/* Success Crown Icon with Glowing Ring */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="relative mb-6"
        >
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr from-amber-400 via-amber-300 to-amber-600 p-[1.5px] shadow-2xl shadow-amber-500/25">
            <div className="w-full h-full bg-[#0a0a0d] rounded-[22px] flex items-center justify-center">
              <Crown className="w-10 h-10 sm:w-12 sm:h-12 text-amber-400 animate-pulse" />
            </div>
          </div>
          <div className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-emerald-500 text-zinc-950 shadow-lg ring-4 ring-[#0e0e13]">
            <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-zinc-950 stroke-[2.5]" />
          </div>
        </motion.div>

        {/* Page 3 Heading: KOHINOOR PREMIUM ACTIVATED */}
        <motion.h1
          initial={{ y: -8, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.35 }}
          className="font-cinzel text-2xl sm:text-3xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500 mb-3"
        >
          KOHINOOR PREMIUM ACTIVATED
        </motion.h1>

        {/* Verified Status Tag */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold tracking-wide mb-6">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Payment Verified • Lifetime Access</span>
        </div>

        {/* UTR Verification Pill */}
        {utrNumber && (
          <div className="mb-6 px-4 py-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs text-zinc-400 flex items-center justify-between w-full max-w-sm">
            <span className="text-zinc-500">UTR / Ref Number:</span>
            <span className="font-mono text-amber-300 font-semibold">{utrNumber}</span>
          </div>
        )}

        {/* Instagram Profile Card */}
        <div className="w-full max-w-sm rounded-2xl bg-gradient-to-b from-zinc-900 to-[#121217] border border-amber-500/30 p-6 sm:p-7 shadow-inner flex flex-col items-center my-2">
          {/* Instagram Icon */}
          <div className="relative mb-4">
            <div className="w-20 h-20 rounded-full p-[2.5px] bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 shadow-xl">
              <div className="w-full h-full rounded-full bg-[#0a0a0e] flex items-center justify-center">
                <Instagram className="w-10 h-10 text-rose-400" />
              </div>
            </div>
            <div className="absolute bottom-0 right-0 p-1 bg-amber-400 rounded-full text-zinc-950 shadow">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Instagram Handle: jaaniii.__121 */}
          <div className="flex items-center gap-1.5 mb-1.5">
            <h2 className="font-mono text-xl sm:text-2xl font-bold text-white tracking-tight">
              {INSTAGRAM_HANDLE}
            </h2>
            <div
              className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-[10px] text-white font-bold"
              title="Verified Profile"
            >
              ✓
            </div>
          </div>

          {/* Text: he is an expensive person */}
          <p className="text-sm font-medium text-amber-200/90 tracking-wide mb-6 text-center italic">
            &ldquo;{INSTAGRAM_TAGLINE}&rdquo;
          </p>

          {/* Action Button: OPEN INSTAGRAM */}
          <a
            id="open-instagram-btn"
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500 hover:opacity-95 active:scale-[0.98] text-white font-bold text-sm tracking-wider uppercase transition-all shadow-lg shadow-rose-500/20 flex items-center justify-center gap-2 text-center"
          >
            <Instagram className="w-4 h-4 text-white" />
            <span>OPEN INSTAGRAM</span>
            <ExternalLink className="w-4 h-4 text-white/80" />
          </a>
        </div>

        {/* Status Confirmation Badge */}
        <div className="mt-6 pt-5 border-t border-zinc-800/80 w-full flex items-center justify-center gap-2 text-xs text-amber-400/90 font-mono font-medium">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Access Unlocked • Profile Active</span>
        </div>
      </div>

      {/* Safety & Compliance Footnote */}
      <div className="mt-6 text-center text-xs text-zinc-500 max-w-md">
        Standard Android and browser navigation active. You can safely close or switch tabs at any time.
      </div>
    </div>
  );
};
