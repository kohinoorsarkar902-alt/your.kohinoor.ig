import React, { useState } from 'react';
import { BookOpen, ShieldCheck, Terminal, Globe, Server, Check, Copy } from 'lucide-react';

interface DocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DocsModal: React.FC<DocsModalProps> = ({ isOpen, onClose }) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyCode = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto"
    >
      <div className="w-full max-w-3xl bg-[#0f0f15] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-[#121219]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <h2 className="font-cinzel text-base sm:text-lg font-bold text-amber-200">
                YOUR KOHINOOR — Technical & Safety Documentation
              </h2>
              <p className="text-xs text-zinc-400">
                Setup, Local Execution, GitHub Pages Deployment & Architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1.5 rounded-lg border border-zinc-800 hover:bg-zinc-800 text-sm"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-6 space-y-6 overflow-y-auto text-sm text-zinc-300">
          {/* Section 1: Safety & Compliance Guarantee */}
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
            <div className="flex items-center gap-2 font-semibold text-emerald-300 text-sm mb-2">
              <ShieldCheck className="w-4 h-4" />
              <span>Full Compliance & Safety Guarantee</span>
            </div>
            <ul className="text-xs space-y-1 text-emerald-200/90 list-disc list-inside">
              <li>No lockouts, ransomware patterns, or aggressive fullscreen trapping.</li>
              <li>Android buttons (Back, Home, Recents, Power, Volume) are 100% unimpeded.</li>
              <li>One-way internal UI navigation prevents accidental state regression while preserving standard browser history.</li>
              <li>Standard browser navigation, tabs, and clean exits remain functional.</li>
              <li>UPI payments use standard, transparent intent URLs with zero device takeover.</li>
            </ul>
          </div>

          {/* Section 2: Complete Project Structure */}
          <div>
            <h3 className="font-cinzel text-sm font-bold text-amber-300 mb-2 flex items-center gap-2">
              <span>1. Project Structure</span>
            </h3>
            <pre className="p-3 bg-[#08080a] border border-zinc-800 rounded-xl text-xs font-mono text-zinc-300 overflow-x-auto">
{`your-kohinoor/
├── index.html                 # HTML5 entry with luxury typography
├── metadata.json              # Applet metadata configuration
├── package.json               # Dependencies & scripts
├── tsconfig.json              # TypeScript configuration
├── vite.config.ts             # Vite + Tailwind CSS plugin
├── src/
│   ├── main.tsx               # React root initialization
│   ├── App.tsx                # Main view router & state management
│   ├── index.css              # Tailwind CSS imports & theme rules
│   ├── types.ts               # Shared types, UPI config, constants
│   └── components/
│       ├── Header.tsx         # Brand header & navigation controls
│       ├── WelcomePage.tsx    # Page 1: Centered luxury card & entry
│       ├── PremiumPage.tsx    # Page 2: Price ₹25, QR code & UPI
│       ├── QRCodeSection.tsx  # Dynamic QR generator with copy actions
│       ├── PaymentStatus.tsx  # Accessible verification feedback
│       ├── PaymentVerification.tsx # 12-digit UTR simulator with disclaimers
│       ├── PremiumActivatedPage.tsx # Page 3: Instagram section & status
│       └── DocsModal.tsx      # In-app technical & deployment guide`}
            </pre>
          </div>

          {/* Section 3: Running Locally */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-cinzel text-sm font-bold text-amber-300 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>2. Instructions for Running Locally</span>
              </h3>
              <button
                onClick={() =>
                  copyCode(
                    `# 1. Clone repository
git clone https://github.com/your-username/your-kohinoor.git
cd your-kohinoor

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open in browser at http://localhost:3000`,
                    'local'
                  )
                }
                className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                {copiedSection === 'local' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'local' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 bg-[#08080a] border border-zinc-800 rounded-xl text-xs font-mono text-zinc-300 overflow-x-auto">
{`# 1. Clone repository
git clone https://github.com/your-username/your-kohinoor.git
cd your-kohinoor

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open in browser at http://localhost:3000`}
            </pre>
          </div>

          {/* Section 4: Deploying to GitHub Pages */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-cinzel text-sm font-bold text-amber-300 flex items-center gap-2">
                <Globe className="w-4 h-4 text-amber-400" />
                <span>3. Instructions for Deploying to GitHub Pages</span>
              </h3>
              <button
                onClick={() =>
                  copyCode(
                    `# Step 1: Install gh-pages
npm install --save-dev gh-pages

# Step 2: In vite.config.ts, set the base path:
# export default defineConfig({
#   base: '/your-kohinoor/',
#   plugins: [react(), tailwindcss()],
# });

# Step 3: Add deploy script in package.json:
# "deploy": "npm run build && gh-pages -d dist"

# Step 4: Run deploy
npm run deploy`,
                    'ghpages'
                  )
                }
                className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                {copiedSection === 'ghpages' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'ghpages' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 bg-[#08080a] border border-zinc-800 rounded-xl text-xs font-mono text-zinc-300 overflow-x-auto">
{`# Step 1: Install gh-pages
npm install --save-dev gh-pages

# Step 2: In vite.config.ts, set base: '/<repo-name>/':
export default defineConfig({
  base: './', // or '/your-kohinoor/'
  plugins: [react(), tailwindcss()],
});

# Step 3: In package.json "scripts", add:
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"

# Step 4: Run the deploy command
npm run deploy`}
            </pre>
          </div>

          {/* Section 5: Demo vs Real Payment Gateway / Backend */}
          <div>
            <h3 className="font-cinzel text-sm font-bold text-amber-300 mb-2 flex items-center gap-2">
              <Server className="w-4 h-4 text-amber-400" />
              <span>4. Demo Mode vs. Production Backend Integration</span>
            </h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <strong className="text-amber-300 block mb-1">What is Demo-Only in this build:</strong>
                <p className="text-zinc-300 leading-relaxed">
                  The client-side UTR validation checks for valid 12-digit Indian UPI Reference (RRN) syntax
                  and simulates a server verification roundtrip. It is explicitly marked with{' '}
                  <code className="text-amber-300 bg-black/40 px-1 py-0.5 rounded">DEMO MODE — Payment verification is simulated</code>{' '}
                  to prevent any false representations.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                <strong className="text-white block mb-1">What is required for a Real Production Gateway:</strong>
                <ol className="list-decimal list-inside space-y-1 text-zinc-300 leading-relaxed">
                  <li>
                    <strong>Payment Gateway / Aggregator:</strong> Integrate a licensed payment aggregator
                    (e.g., Razorpay, Cashfree, PhonePe PG, Paytm PG, or bank API).
                  </li>
                  <li>
                    <strong>Secure Server API:</strong> Implement a backend endpoint (e.g., <code className="text-amber-300">POST /api/create-order</code>)
                    generating an authorized Order ID before prompting payment.
                  </li>
                  <li>
                    <strong>Webhook Listener:</strong> Implement <code className="text-amber-300">POST /api/webhook/payment</code> with cryptographic
                    signature verification (HMAC-SHA256) triggered directly by the payment provider on payment settlement.
                  </li>
                  <li>
                    <strong>Idempotent Fulfillment:</strong> Store verified transaction IDs in a database
                    to prevent replay attacks or reuse of arbitrary UTR numbers.
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-[#121219] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs uppercase tracking-wider transition-colors"
          >
            Understood & Close
          </button>
        </div>
      </div>
    </div>
  );
};
