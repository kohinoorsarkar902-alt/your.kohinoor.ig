import React from 'react';
import { Gem, BookOpen, ShieldCheck } from 'lucide-react';
import { PageType } from '../types.ts';

interface HeaderProps {
  currentPage: PageType;
  onOpenDocs: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onOpenDocs }) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-amber-500/15 bg-[#09090b]/85 backdrop-blur-md">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand Logo & Title (One-way: no backward navigation) */}
        <div className="flex items-center gap-2.5 p-1 select-none">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 p-[1px] shadow-lg shadow-amber-500/10">
            <div className="w-full h-full bg-[#0d0d11] rounded-[7px] flex items-center justify-center">
              <Gem className="w-5 h-5 text-amber-400" />
            </div>
          </div>
          <div>
            <span className="font-cinzel text-base sm:text-lg font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-100">
              YOUR KOHINOOR
            </span>
            <span className="hidden sm:block text-[10px] text-amber-400/60 font-medium tracking-widest uppercase">
              Official Portal
            </span>
          </div>
        </div>

        {/* Step Indicator & Docs modal (Strictly one-way: no website back buttons) */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Docs / Safety specs modal */}
          <button
            onClick={onOpenDocs}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/15 text-amber-300 text-xs font-medium transition-colors"
            title="View Technical Specs & Safety Guides"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Docs & Guides</span>
            <span className="sm:hidden">Docs</span>
          </button>

          {/* Forward progression badge */}
          {currentPage === 'welcome' && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-400">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              <span>Step 1 of 3</span>
            </div>
          )}

          {currentPage === 'premium' && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-mono text-amber-300 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              <span>Step 2 of 3</span>
            </div>
          )}

          {currentPage === 'activated' && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-xs font-mono text-emerald-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Step 3 of 3 • Active</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
