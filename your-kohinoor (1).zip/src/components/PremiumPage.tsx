import React, { useState } from 'react';
import { Gem, Smartphone, ShieldCheck } from 'lucide-react';
import { KOHINOOR_UPI_CONFIG } from '../types.ts';
import { QRCodeSection } from './QRCodeSection.tsx';
import { PaymentVerification } from './PaymentVerification.tsx';
import { UPIAppSelector } from './UPIAppSelector.tsx';

interface PremiumPageProps {
  onVerificationSuccess: (utr: string) => void;
}

export const PremiumPage: React.FC<PremiumPageProps> = ({
  onVerificationSuccess,
}) => {
  const [showAppsList, setShowAppsList] = useState(true);
  const [launchedAppName, setLaunchedAppName] = useState<string | null>(null);

  // Standard UPI URI format accepted across Indian Banking & UPI Apps
  const upiUri = `upi://pay?pa=${encodeURIComponent(KOHINOOR_UPI_CONFIG.upiId)}&pn=${encodeURIComponent(
    KOHINOOR_UPI_CONFIG.payeeName
  )}&am=${KOHINOOR_UPI_CONFIG.amount}&cu=${KOHINOOR_UPI_CONFIG.currency}&tn=${encodeURIComponent(
    KOHINOOR_UPI_CONFIG.transactionNote
  )}`;

  const handleGetPremium = () => {
    setLaunchedAppName('UPI App Chooser');
    // Launch standard UPI URI scheme via deep link
    try {
      window.location.href = upiUri;
    } catch {
      // Browser fallback handled cleanly
    }

    // Ensure apps list is visible and scroll to verification section
    setShowAppsList(true);
    setTimeout(() => {
      const section = document.getElementById('payment-verification-section');
      section?.scrollIntoView({ behavior: 'smooth' });
    }, 500);
  };

  const handleAppLaunched = (appName: string) => {
    setLaunchedAppName(appName);
    setTimeout(() => {
      const section = document.getElementById('payment-verification-section');
      section?.scrollIntoView({ behavior: 'smooth' });
    }, 400);
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6 sm:py-10 space-y-8">
      {/* Top Status Header (Strictly One-Way: No Back Button) */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          <span className="text-xs font-mono font-semibold tracking-wider text-amber-300 uppercase">
            Step 2 of 3: Premium Access
          </span>
        </div>
        <span className="text-xs text-zinc-500 font-mono">₹25 One-Time</span>
      </div>

      {/* Main Premium Card */}
      <div
        id="premium-main-card"
        className="rounded-3xl bg-[#0e0e13] border border-amber-500/30 p-6 sm:p-9 shadow-2xl shadow-black/80 flex flex-col items-center text-center relative overflow-hidden"
      >
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/5 blur-3xl rounded-full pointer-events-none" />

        {/* Gem Icon */}
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-4">
          <Gem className="w-7 h-7 text-amber-400" />
        </div>

        {/* Display: YOUR KOHINOOR PREMIUM */}
        <h2 className="font-cinzel text-2xl sm:text-3xl font-extrabold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500 mb-2">
          YOUR KOHINOOR PREMIUM
        </h2>

        {/* Premium Price: ₹25 */}
        <div className="my-3 flex items-baseline justify-center gap-1">
          <span className="font-cinzel text-4xl sm:text-5xl font-black text-amber-300">
            ₹{parseInt(KOHINOOR_UPI_CONFIG.amount, 10)}
          </span>
          <span className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">
            One-time
          </span>
        </div>

        {/* Add: ₹25 Premium */}
        <div className="mb-6 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-200 text-sm font-bold tracking-wide">
          <span>₹25 Premium</span>
        </div>

        {/* QR Code Section with UPI ID */}
        <div className="w-full my-3">
          <QRCodeSection upiUri={upiUri} />
        </div>

        {/* Primary Action Button: GET PREMIUM */}
        <div className="w-full max-w-sm mt-6 flex flex-col items-center">
          <button
            id="get-premium-btn"
            onClick={handleGetPremium}
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.98] text-zinc-950 font-extrabold text-base tracking-wider uppercase transition-all shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2.5"
          >
            <Smartphone className="w-5 h-5 text-zinc-950" />
            <span>GET PREMIUM</span>
          </button>

          {/* Hint Below as explicitly requested */}
          <p className="text-xs text-amber-200/80 font-medium mt-3 text-center leading-relaxed">
            &ldquo;Premium activate karne ke liye ₹25 ka payment complete karein.&rdquo;
          </p>
        </div>
      </div>

      {/* Standard UPI Payment App Options */}
      {showAppsList && (
        <UPIAppSelector
          onAppLaunched={handleAppLaunched}
          standardUpiUri={upiUri}
        />
      )}

      {/* Payment Verification Section (UTR Entry & Verification) */}
      <PaymentVerification
        onVerificationSuccess={onVerificationSuccess}
        launchedAppName={launchedAppName}
      />

      {/* Safety Compliance Note */}
      <div className="text-center text-xs text-zinc-500 flex items-center justify-center gap-2">
        <ShieldCheck className="w-4 h-4 text-emerald-500/80" />
        <span>Standard Indian Banking UPI Format • Safe & Secure</span>
      </div>
    </div>
  );
};
