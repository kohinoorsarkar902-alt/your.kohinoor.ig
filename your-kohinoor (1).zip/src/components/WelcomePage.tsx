import React from 'react';
import { Gem, ArrowRight, Sparkles, Shield } from 'lucide-react';
import { PageType } from '../types.ts';

interface WelcomePageProps {
  onNavigate: (page: PageType) => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({ onNavigate }) => {
  return (
    <div className="w-full max-w-xl mx-auto px-4 py-8 sm:py-16 flex flex-col items-center justify-center">
      {/* Centered Main Card */}
      <div
        id="welcome-card"
        className="w-full relative rounded-3xl bg-[#0f0f14] border border-amber-500/25 p-7 sm:p-10 text-center shadow-2xl shadow-black/80 flex flex-col items-center"
      >
        {/* Subtle Decorative Golden Glow Behind Emblem */}
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-36 h-36 bg-amber-500/10 blur-2xl rounded-full pointer-events-none" />

        {/* Diamond / Kohinoor Luxury Emblem */}
        <div className="relative mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-400 via-amber-200 to-amber-600 p-[1.5px] shadow-xl shadow-amber-500/20">
            <div className="w-full h-full bg-[#0a0a0d] rounded-[15px] flex items-center justify-center">
              <Gem className="w-10 h-10 text-amber-400" />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 p-1.5 rounded-full bg-amber-500 text-zinc-950 shadow-md">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Website Title: YOUR KOHINOOR */}
        <h1 className="font-cinzel text-3xl sm:text-4xl font-extrabold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500 mb-3">
          YOUR KOHINOOR
        </h1>

        {/* Tagline / Subtitle */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-medium tracking-wide mb-6">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>Exclusive Access Experience</span>
        </div>

        {/* Hint telling user to click OPEN KOHINOOR PAGE */}
        <p className="text-sm sm:text-base text-zinc-300 font-normal leading-relaxed max-w-sm mb-8">
          &ldquo;OPEN KOHINOOR PAGE par click karke aage badhein.&rdquo;
        </p>

        {/* Primary Action Button: OPEN KOHINOOR PAGE */}
        <button
          id="open-kohinoor-btn"
          onClick={() => onNavigate('premium')}
          className="w-full sm:w-auto min-w-[260px] py-4 px-8 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.98] text-zinc-950 font-bold text-base tracking-wider uppercase transition-all shadow-xl shadow-amber-500/25 flex items-center justify-center gap-3 group"
        >
          <span>OPEN KOHINOOR PAGE</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform text-zinc-950" />
        </button>

        {/* Forward-only Step Progress Indicator */}
        <div className="mt-8 pt-5 border-t border-zinc-800/80 w-full flex items-center justify-center gap-2 text-xs text-zinc-400 font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          <span>Step 1 of 3 • Click button to proceed</span>
        </div>
      </div>

      {/* Safety Assurance Footnote */}
      <div className="mt-6 text-center text-xs text-zinc-500 max-w-md">
        Standard web application. Standard browser and Android system controls remain active.
      </div>
    </div>
  );
};
