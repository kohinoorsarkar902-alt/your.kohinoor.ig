import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Check, Download, QrCode as QrIcon, ShieldCheck } from 'lucide-react';
import { KOHINOOR_UPI_CONFIG } from '../types.ts';

interface QRCodeSectionProps {
  upiUri: string;
}

export const QRCodeSection: React.FC<QRCodeSectionProps> = ({ upiUri }) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedId, setCopiedId] = useState(false);
  const [copiedUri, setCopiedUri] = useState(false);

  useEffect(() => {
    QRCode.toDataURL(upiUri, {
      width: 320,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('Error generating QR code:', err));
  }, [upiUri]);

  const handleCopyUPI = async () => {
    try {
      await navigator.clipboard.writeText(KOHINOOR_UPI_CONFIG.upiId);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } catch {
      // Fallback
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleCopyUri = async () => {
    try {
      await navigator.clipboard.writeText(upiUri);
      setCopiedUri(true);
      setTimeout(() => setCopiedUri(false), 2000);
    } catch {
      setCopiedUri(true);
      setTimeout(() => setCopiedUri(false), 2000);
    }
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = 'YOUR-KOHINOOR-UPI-QR.png';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* QR Code Container with Gold Accent Framing */}
      <div className="relative p-1 rounded-2xl bg-gradient-to-b from-amber-400/40 via-amber-600/20 to-zinc-800 shadow-2xl shadow-amber-500/10">
        <div className="bg-[#0f0f14] p-5 sm:p-6 rounded-[14px] flex flex-col items-center">
          {/* Top Label */}
          <div className="flex items-center gap-2 mb-3 text-amber-300 text-xs font-semibold uppercase tracking-wider">
            <QrIcon className="w-4 h-4" />
            <span>Scan with any UPI App</span>
          </div>

          {/* Actual QR Image */}
          <div className="p-3 bg-white rounded-xl shadow-inner flex items-center justify-center min-w-[200px] min-h-[200px]">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="YOUR KOHINOOR UPI QR Code"
                className="w-48 h-48 sm:w-52 sm:h-52 object-contain"
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center text-zinc-500 text-xs animate-pulse">
                Generating QR code...
              </div>
            )}
          </div>

          {/* Amount Badge */}
          <div className="mt-3 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-sm tracking-wide">
            Amount: ₹{KOHINOOR_UPI_CONFIG.amount}
          </div>

          {/* Action buttons under QR */}
          <div className="mt-4 flex flex-wrap gap-2 justify-center">
            <button
              onClick={handleDownloadQR}
              disabled={!qrDataUrl}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-300 bg-zinc-800/80 hover:bg-zinc-700 hover:text-white border border-zinc-700 transition-colors disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Save QR</span>
            </button>
            <button
              onClick={handleCopyUri}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-300 bg-zinc-800/80 hover:bg-zinc-700 hover:text-white border border-zinc-700 transition-colors"
            >
              {copiedUri ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">URI Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-amber-400" />
                  <span>Copy UPI Link</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* UPI ID display with direct copy */}
      <div className="mt-4 w-full max-w-sm bg-zinc-900/90 border border-amber-500/20 rounded-xl p-3 flex items-center justify-between gap-3">
        <div className="overflow-hidden">
          <div className="text-[11px] text-zinc-400 uppercase tracking-wider font-semibold">
            VPA / UPI ID
          </div>
          <div className="font-mono text-xs sm:text-sm text-amber-200 font-medium truncate select-all">
            {KOHINOOR_UPI_CONFIG.upiId}
          </div>
        </div>

        <button
          onClick={handleCopyUPI}
          className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-medium transition-colors"
          title="Copy UPI ID"
        >
          {copiedId ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400 font-semibold">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      {/* Supported UPI Apps info */}
      <div className="mt-3 flex items-center gap-2 text-zinc-400 text-xs text-center">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
        <span>Supports Google Pay, PhonePe, Paytm, BHIM & All UPI Apps</span>
      </div>
    </div>
  );
};
