import React from 'react';
import { Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';

interface PaymentStatusProps {
  status: 'idle' | 'verifying' | 'verified' | 'error';
  message?: string | null;
}

export const PaymentStatus: React.FC<PaymentStatusProps> = ({ status, message }) => {
  if (status === 'idle' && !message) return null;

  return (
    <div className="w-full">
      {status === 'verifying' && (
        <div className="flex items-center gap-3 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-sm">
          <Loader2 className="w-5 h-5 text-amber-400 animate-spin flex-shrink-0" />
          <div>
            <div className="font-semibold text-amber-300">Checking Reference Number...</div>
            <div className="text-xs text-amber-200/80">
              Simulating transaction handshake. Do not close this browser tab.
            </div>
          </div>
        </div>
      )}

      {status === 'error' && (
        <div className="flex items-start gap-3 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-200 text-sm">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-red-300">Verification Alert</div>
            <div className="text-xs text-red-200/90 mt-0.5">
              {message || 'Invalid UTR format. Standard UPI UTR is a 12-digit number.'}
            </div>
          </div>
        </div>
      )}

      {status === 'verified' && (
        <div className="flex items-start gap-3 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 text-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-emerald-300">Demo Verification Accepted</div>
            <div className="text-xs text-emerald-200/80 mt-0.5">
              {message || 'Simulated transaction validated successfully.'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
