import React, { useState } from 'react';
import { ShieldCheck, Info, Check, Sparkles, ArrowRight } from 'lucide-react';
import { PaymentStatus } from './PaymentStatus.tsx';

interface PaymentVerificationProps {
  onVerificationSuccess: (utr: string) => void;
  launchedAppName?: string | null;
}

export const PaymentVerification: React.FC<PaymentVerificationProps> = ({
  onVerificationSuccess,
  launchedAppName,
}) => {
  const [utrNumber, setUtrNumber] = useState('');
  const [status, setStatus] = useState<'idle' | 'verifying' | 'verified' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // UTR format validation: UPI UTR (Unique Transaction Reference) / RRN is standard 12-digit numeric
  const validateUTR = (val: string) => {
    const cleaned = val.trim();
    if (!cleaned) {
      return { valid: false, error: 'Please enter a valid UTR (UPI Reference Number / RRN).' };
    }
    // Checks standard 12-digit numeric format
    const isTwelveDigits = /^\d{12}$/.test(cleaned);
    if (!isTwelveDigits) {
      return {
        valid: false,
        error: 'Please enter a valid UTR. A standard UPI transaction reference number consists of exactly 12 digits (e.g., 426812345678).',
      };
    }
    // Check against repeated single digit dummy like 000000000000
    if (/^(\d)\1{11}$/.test(cleaned)) {
      return {
        valid: false,
        error: 'Please enter a valid UTR number. Repeating sequence detected.',
      };
    }
    return { valid: true, error: null };
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const validation = validateUTR(utrNumber);
    if (!validation.valid) {
      setStatus('error');
      setErrorMessage(validation.error);
      return;
    }

    setStatus('verifying');

    // Simulate verification handshake with backend
    setTimeout(() => {
      setStatus('verified');
      setTimeout(() => {
        onVerificationSuccess(utrNumber.trim());
      }, 900);
    }, 1600);
  };

  const handleFillDemoUTR = () => {
    // Generates a valid formatted 12-digit sample reference
    const demoUTR = '4268' + Math.floor(10000000 + Math.random() * 90000000).toString();
    setUtrNumber(demoUTR);
    setStatus('idle');
    setErrorMessage(null);
  };

  return (
    <div id="payment-verification-section" className="w-full bg-[#111116] border border-amber-500/25 rounded-2xl p-5 sm:p-7 shadow-xl shadow-black/40">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-4 mb-5">
        <div>
          <h3 className="font-cinzel text-lg sm:text-xl font-bold text-amber-200 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            Payment Verification
          </h3>
          {/* Prompt request: "Payment complete? Enter your UTR number to verify your payment." */}
          <p className="text-xs sm:text-sm text-amber-300 font-medium mt-1">
            &ldquo;Payment complete? Enter your UTR number to verify your payment.&rdquo;
          </p>
          {launchedAppName && (
            <p className="text-[11px] text-zinc-400 mt-1">
              Returned from <span className="text-white font-semibold">{launchedAppName}</span>? Enter the 12-digit reference number from your app receipt.
            </p>
          )}
        </div>

        {/* DEMO MODE BADGE - strictly per prompt requirements */}
        <div className="self-start sm:self-auto px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-semibold tracking-wide flex items-center gap-1.5 flex-shrink-0">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          <span>DEMO MODE — Payment verification is simulated</span>
        </div>
      </div>

      {/* Safety & Real Architecture Notice */}
      <div className="mb-5 p-3.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs text-zinc-400 space-y-1.5">
        <div className="flex items-center gap-2 text-zinc-200 font-semibold">
          <Info className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>Production Security Guidelines:</span>
        </div>
        <ul className="list-disc list-inside space-y-0.5 text-[11px] text-zinc-300 pl-1 leading-relaxed">
          <li>Verify the ₹25 transaction using a legitimate payment gateway / bank API on a secure backend.</li>
          <li>Never trust only client-side UTR input.</li>
          <li>Never unlock Premium merely because the user entered a random UTR number.</li>
          <li>Match the transaction amount (₹25), payee (kohinoorsarkar902@okicici), transaction note (YOUR KOHINOOR Premium), and payment status via bank webhook.</li>
        </ul>
      </div>

      {/* Verification Form */}
      <form onSubmit={handleVerify} className="space-y-4">
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="utr-input"
              className="text-xs font-bold text-amber-200 uppercase tracking-wider"
            >
              UTR NUMBER
            </label>
            <button
              type="button"
              onClick={handleFillDemoUTR}
              className="text-[11px] text-amber-400 hover:text-amber-300 underline underline-offset-2 flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3" />
              Use Sample 12-Digit UTR
            </button>
          </div>

          <div className="relative">
            <input
              id="utr-input"
              type="text"
              inputMode="numeric"
              maxLength={12}
              value={utrNumber}
              onChange={(e) => {
                // allow only digits
                const val = e.target.value.replace(/\D/g, '');
                setUtrNumber(val);
                if (status === 'error') {
                  setStatus('idle');
                  setErrorMessage(null);
                }
              }}
              placeholder="Enter 12-digit UTR (e.g. 426891045231)"
              disabled={status === 'verifying' || status === 'verified'}
              className={`w-full bg-[#0a0a0d] border ${
                status === 'error'
                  ? 'border-red-500 focus:border-red-400 focus:ring-2 focus:ring-red-400/20'
                  : 'border-zinc-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20'
              } text-amber-100 placeholder-zinc-600 rounded-xl px-4 py-3 text-sm font-mono tracking-widest outline-none transition-all disabled:opacity-50`}
            />
            <div className="absolute right-3 top-3 text-[11px] font-mono text-zinc-500">
              {utrNumber.length}/12
            </div>
          </div>
          <p className="text-[11px] text-zinc-500 mt-1">
            Standard 12-digit numeric reference number generated upon completing the ₹25 payment.
          </p>
        </div>

        {/* Status Component */}
        <PaymentStatus status={status} message={errorMessage} />

        {/* Submit Button: VERIFY PAYMENT */}
        <button
          id="verify-payment-btn"
          type="submit"
          disabled={status === 'verifying' || status === 'verified'}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.99] text-zinc-950 font-bold text-sm tracking-wider uppercase transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none flex items-center justify-center gap-2"
        >
          {status === 'verifying' ? (
            <span>Verifying with Server...</span>
          ) : status === 'verified' ? (
            <>
              <Check className="w-4 h-4 text-zinc-950" />
              <span>Verified! Redirecting...</span>
            </>
          ) : (
            <>
              <span>VERIFY PAYMENT</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>
    </div>
  );
};
