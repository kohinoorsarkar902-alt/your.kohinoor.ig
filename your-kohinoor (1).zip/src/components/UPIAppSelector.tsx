import React, { useState } from 'react';
import {
  Copy,
  Check,
  ExternalLink,
  Smartphone,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { KOHINOOR_UPI_CONFIG } from '../types.ts';

interface UPIAppSelectorProps {
  onAppLaunched: (appName: string) => void;
  standardUpiUri: string;
}

interface UPIAppItem {
  id: string;
  name: string;
  subtitle: string;
  schemeUri: string;
  brandColor: string;
  badgeBg: string;
  iconType: 'gpay' | 'phonepe' | 'paytm' | 'bhim' | 'other';
}

export const UPIAppSelector: React.FC<UPIAppSelectorProps> = ({
  onAppLaunched,
  standardUpiUri,
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [lastLaunchedApp, setLastLaunchedApp] = useState<string | null>(null);

  // Deep-link URIs with the exact parameters requested
  const encodedPa = encodeURIComponent(KOHINOOR_UPI_CONFIG.upiId);
  const encodedPn = encodeURIComponent(KOHINOOR_UPI_CONFIG.payeeName);
  const encodedAm = encodeURIComponent(KOHINOOR_UPI_CONFIG.amount);
  const encodedCu = encodeURIComponent(KOHINOOR_UPI_CONFIG.currency);
  const encodedTn = encodeURIComponent(KOHINOOR_UPI_CONFIG.transactionNote);

  const queryParams = `pa=${encodedPa}&pn=${encodedPn}&am=${encodedAm}&cu=${encodedCu}&tn=${encodedTn}`;

  const upiApps: UPIAppItem[] = [
    {
      id: 'gpay',
      name: 'Google Pay',
      subtitle: 'Instant checkout via Tez / Google Pay',
      schemeUri: `tez://upi/pay?${queryParams}`,
      brandColor: 'border-blue-500/30 hover:border-blue-500/60',
      badgeBg: 'bg-blue-500/10 text-blue-400',
      iconType: 'gpay',
    },
    {
      id: 'phonepe',
      name: 'PhonePe',
      subtitle: 'Instant payment via PhonePe app',
      schemeUri: `phonepe://pay?${queryParams}`,
      brandColor: 'border-purple-500/30 hover:border-purple-500/60',
      badgeBg: 'bg-purple-500/10 text-purple-400',
      iconType: 'phonepe',
    },
    {
      id: 'paytm',
      name: 'Paytm',
      subtitle: 'Pay via Paytm UPI or Wallet',
      schemeUri: `paytmmp://pay?${queryParams}`,
      brandColor: 'border-sky-500/30 hover:border-sky-500/60',
      badgeBg: 'bg-sky-500/10 text-sky-400',
      iconType: 'paytm',
    },
    {
      id: 'bhim',
      name: 'BHIM',
      subtitle: 'Official NPCI BHIM UPI application',
      schemeUri: `bhim://pay?${queryParams}`,
      brandColor: 'border-amber-500/30 hover:border-amber-500/60',
      badgeBg: 'bg-amber-500/10 text-amber-400',
      iconType: 'bhim',
    },
    {
      id: 'other',
      name: 'Other available UPI apps',
      subtitle: 'Standard Android system chooser (Cred, Amazon Pay, Bank apps)',
      schemeUri: standardUpiUri,
      brandColor: 'border-zinc-700 hover:border-amber-400/50',
      badgeBg: 'bg-zinc-800 text-zinc-300',
      iconType: 'other',
    },
  ];

  const handleCopyUPI = async () => {
    try {
      await navigator.clipboard.writeText(KOHINOOR_UPI_CONFIG.upiId);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } catch {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handlePay = (app: UPIAppItem) => {
    setLastLaunchedApp(app.name);
    onAppLaunched(app.name);

    // Standard Android deep link invocation
    try {
      window.location.href = app.schemeUri;
    } catch {
      window.location.href = standardUpiUri;
    }
  };

  const renderIcon = (type: UPIAppItem['iconType']) => {
    switch (type) {
      case 'gpay':
        return (
          <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center p-1.5 shadow-md flex-shrink-0">
            <svg viewBox="0 0 24 24" className="w-6 h-6">
              <path
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                fill="#4285F4"
              />
              <path
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                fill="#34A853"
              />
              <path
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                fill="#FBBC05"
              />
              <path
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                fill="#EA4335"
              />
            </svg>
          </div>
        );
      case 'phonepe':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#5f259f] flex items-center justify-center p-1.5 shadow-md flex-shrink-0">
            <span className="text-white font-extrabold text-base tracking-tighter">पे</span>
          </div>
        );
      case 'paytm':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#002e6e] flex items-center justify-center p-1 shadow-md flex-shrink-0">
            <div className="flex flex-col items-center leading-none">
              <span className="text-[#00baf2] font-black text-[10px] tracking-tight">Pay</span>
              <span className="text-white font-black text-[9px] tracking-tight">tm</span>
            </div>
          </div>
        );
      case 'bhim':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#004e38] border border-orange-500/40 flex items-center justify-center p-1 shadow-md flex-shrink-0">
            <div className="flex flex-col items-center leading-none">
              <span className="text-[#ff9933] font-black text-[9px]">BH</span>
              <span className="text-[#138808] font-black text-[9px]">IM</span>
            </div>
          </div>
        );
      case 'other':
      default:
        return (
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center p-2 shadow-md flex-shrink-0">
            <Smartphone className="w-5 h-5 text-zinc-950" />
          </div>
        );
    }
  };

  return (
    <div id="upi-app-selector-card" className="w-full space-y-4">
      {/* Payment Selection Card */}
      <div className="rounded-3xl bg-[#0e0e13] border border-amber-500/35 p-6 sm:p-8 shadow-2xl shadow-black/80 relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/5 blur-3xl rounded-full pointer-events-none" />

        {/* Header Display */}
        <div className="text-center pb-5 border-b border-zinc-800">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Fast Checkout Apps</span>
          </div>

          <h3 className="font-cinzel text-xl sm:text-2xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500">
            Select Your UPI App
          </h3>

          {/* Amount and UPI ID copy */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
            <span className="text-xs text-zinc-400 font-medium">₹25 to</span>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 border border-amber-500/20">
              <span className="font-mono text-xs text-amber-200 font-semibold select-all">
                {KOHINOOR_UPI_CONFIG.upiId}
              </span>
              <button
                onClick={handleCopyUPI}
                className="p-0.5 rounded hover:bg-zinc-800 text-amber-400 transition-colors"
                title="Copy UPI ID"
              >
                {copiedId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>

        {/* UPI Apps List */}
        <div className="mt-5 space-y-2.5">
          {upiApps.map((app) => (
            <div
              key={app.id}
              className={`p-3 sm:p-3.5 rounded-2xl bg-zinc-900/70 border ${app.brandColor} transition-all duration-200 flex items-center justify-between gap-3 hover:bg-zinc-900`}
            >
              {/* Left: Icon & Info */}
              <div className="flex items-center gap-3 overflow-hidden">
                {renderIcon(app.iconType)}
                <div className="text-left overflow-hidden">
                  <div className="font-semibold text-white text-sm sm:text-base flex items-center gap-1.5 truncate">
                    <span>{app.name}</span>
                  </div>
                  <div className="text-[11px] text-zinc-400 truncate">
                    {app.subtitle}
                  </div>
                </div>
              </div>

              {/* Right: A clear PAY ₹25 button */}
              <button
                id={`pay-btn-${app.id}`}
                onClick={() => handlePay(app)}
                className="flex-shrink-0 py-2 px-3.5 sm:px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.98] text-zinc-950 font-bold text-xs sm:text-sm tracking-wider uppercase transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
              >
                <span>PAY ₹25</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Feedback when an app has been triggered */}
        {lastLaunchedApp && (
          <div className="mt-5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-2.5 animate-in fade-in">
            <ShieldCheck className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold text-amber-300">
                Opening {lastLaunchedApp}...
              </strong>
              <div className="text-[11px] text-zinc-300 mt-0.5">
                Complete your ₹25 payment in the app, then enter your 12-digit UTR
                number below.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
