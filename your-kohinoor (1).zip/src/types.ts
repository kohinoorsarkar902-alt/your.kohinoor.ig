export type PageType = 'welcome' | 'premium' | 'activated';

export interface PaymentState {
  utrNumber: string;
  isVerifying: boolean;
  isVerified: boolean;
  errorMessage: string | null;
  verifiedAt?: string;
  methodUsed?: string;
}

export interface UPIConfig {
  upiId: string;
  payeeName: string;
  amount: string;
  currency: string;
  transactionNote: string;
}

export const KOHINOOR_UPI_CONFIG: UPIConfig = {
  upiId: 'kohinoorsarkar902@okicici',
  payeeName: 'YOUR KOHINOOR',
  amount: '25.00',
  currency: 'INR',
  transactionNote: 'YOUR KOHINOOR Premium',
};

export const INSTAGRAM_HANDLE = 'jaaniii.__121';
export const INSTAGRAM_TAGLINE = 'he is an expensive person';
export const INSTAGRAM_URL = 'https://www.instagram.com/jaaniii.__121';
