import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { PageType } from './types.ts';
import { Header } from './components/Header.tsx';
import { WelcomePage } from './components/WelcomePage.tsx';
import { PremiumPage } from './components/PremiumPage.tsx';
import { PremiumActivatedPage } from './components/PremiumActivatedPage.tsx';
import { DocsModal } from './components/DocsModal.tsx';
import { ShieldCheck, Gem } from 'lucide-react';

const getInitialPage = (): PageType => {
  if (typeof window !== 'undefined') {
    const hash = window.location.hash.replace('#', '') as PageType;
    if (hash === 'welcome' || hash === 'premium' || hash === 'activated') {
      return hash;
    }
  }
  return 'welcome';
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>(getInitialPage);
  const [verifiedUTR, setVerifiedUTR] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('kohinoor_verified_utr') || '';
    }
    return '';
  });
  const [isDocsOpen, setIsDocsOpen] = useState<boolean>(false);

  // Synchronize with normal browser history and hash navigation
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state?.page) {
        setCurrentPage(event.state.page);
      } else {
        const hash = window.location.hash.replace('#', '') as PageType;
        if (hash === 'welcome' || hash === 'premium' || hash === 'activated') {
          setCurrentPage(hash);
        } else {
          setCurrentPage('welcome');
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateTo = (page: PageType) => {
    // Strict one-way internal progression: welcome (1) -> premium (2) -> activated (3)
    const pageRank: Record<PageType, number> = {
      welcome: 1,
      premium: 2,
      activated: 3,
    };

    // Prevent the application's internal router from navigating backward
    if (pageRank[page] > pageRank[currentPage]) {
      window.history.pushState({ page }, '', `#${page}`);
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleVerificationSuccess = (utr: string) => {
    setVerifiedUTR(utr);
    try {
      sessionStorage.setItem('kohinoor_verified_utr', utr);
    } catch {
      // Storage quota or restriction handled safely
    }
    navigateTo('activated');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#08080a] text-zinc-100 selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Header */}
      <Header
        currentPage={currentPage}
        onOpenDocs={() => setIsDocsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center items-center relative z-10 py-4 sm:py-8">
        <AnimatePresence mode="wait">
          {currentPage === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
              className="w-full"
            >
              <WelcomePage onNavigate={navigateTo} />
            </motion.div>
          )}

          {currentPage === 'premium' && (
            <motion.div
              key="premium"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
              className="w-full"
            >
              <PremiumPage
                onVerificationSuccess={handleVerificationSuccess}
              />
            </motion.div>
          )}

          {currentPage === 'activated' && (
            <motion.div
              key="activated"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
              className="w-full"
            >
              <PremiumActivatedPage utrNumber={verifiedUTR} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Safety & Info Footer */}
      <footer className="w-full border-t border-zinc-800/80 bg-[#0a0a0e] py-6 px-4 text-center text-xs text-zinc-500 space-y-2">
        <div className="flex items-center justify-center gap-2 text-amber-400/80 font-cinzel text-xs font-semibold">
          <Gem className="w-3.5 h-3.5 text-amber-400" />
          <span>YOUR KOHINOOR</span>
        </div>
        <p className="max-w-md mx-auto text-zinc-400">
          A secure, open web experience. Built with strict adherence to system safety, standard Android
          navigation, and non-intrusive payment flows.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 pt-1 text-[11px] text-zinc-500">
          <button
            onClick={() => setIsDocsOpen(true)}
            className="hover:text-amber-300 underline underline-offset-2"
          >
            Technical Setup & Deployment Guide
          </button>
          <span>•</span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" /> Standard Android & Browser Controls
          </span>
        </div>
      </footer>

      {/* Documentation & Safety Modal */}
      <DocsModal isOpen={isDocsOpen} onClose={() => setIsDocsOpen(false)} />
    </div>
  );
}
