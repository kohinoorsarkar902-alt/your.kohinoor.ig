# YOUR KOHINOOR

A modern, responsive black and gold web application built with React, TypeScript, Vite, and Tailwind CSS.

---

## 🛡️ Safety & Open Web Compliance

This application is strictly designed as a legitimate, transparent web application adhering to all web platform standards:
- **No System Hijacking:** Does **not** disable or block Android navigation buttons (Back, Home, Recents, Power, Volume).
- **No Trapping:** Does **not** use deceptive fullscreen traps, ransomware loops, or attempt to prevent leaving or closing the tab.
- **Normal Navigation:** Back and forward browser history is preserved. An explicit "Exit / Back" button is always visible.
- **Safe UPI Handshake:** Uses standard `upi://pay` intents without hijacking applications or forcing payment.
- **Transparent Verification:** UTR verification is explicitly disclaimed with:
  `DEMO MODE — Payment verification is simulated`
  and does not falsely claim a real bank settlement.

---

## 📁 1. Project Structure

```
your-kohinoor/
├── index.html                   # HTML entry point with luxury fonts & meta tags
├── metadata.json                # Project metadata
├── package.json                 # Project dependencies and npm scripts
├── tsconfig.json                # Strict TypeScript configuration
├── vite.config.ts               # Vite configuration with Tailwind CSS plugin
├── README.md                    # Setup, GitHub Pages, and Architecture Guide
└── src/
    ├── main.tsx                 # React DOM mount point
    ├── App.tsx                  # Main router, page transitions & state orchestrator
    ├── index.css                # Tailwind imports & custom typography rules
    ├── types.ts                 # PageType, UPI configuration, and Instagram constants
    └── components/
        ├── Header.tsx           # Brand header, navigation badge, exit link & docs trigger
        ├── WelcomePage.tsx      # Page 1: Centered luxury card, hint, & navigation
        ├── PremiumPage.tsx      # Page 2: Price ₹25, UPI ID, QR code & payment options
        ├── QRCodeSection.tsx    # Crisp QR generator, UPI copying & download feature
        ├── PaymentStatus.tsx    # Status messages (verifying, error, verified)
        ├── PaymentVerification.tsx # 12-digit UTR simulator with demo disclaimers
        ├── PremiumActivatedPage.tsx # Page 3: Instagram section (@jaaniii.__121) & status
        └── DocsModal.tsx        # In-app interactive documentation & deployment guide
```

---

## 💻 2. Instructions for Running Locally

### Prerequisites
- Node.js 18+ installed
- npm or pnpm or yarn

### Steps
```bash
# 1. Clone the repository
git clone https://github.com/your-username/your-kohinoor.git
cd your-kohinoor

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open in browser
# Dev server runs on http://localhost:3000
```

---

## 🌐 3. Instructions for Deploying to GitHub Pages

GitHub Pages serves static sites from a branch (e.g. `gh-pages` or `main/docs`).

### Step 1: Install `gh-pages`
```bash
npm install --save-dev gh-pages
```

### Step 2: Configure `base` in `vite.config.ts`
Set the base to match your repository name:
```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  base: '/your-kohinoor/', // Replace with your repository name, or './' for relative paths
  plugins: [react(), tailwindcss()],
});
```

### Step 3: Add Deploy Scripts in `package.json`
Add the following to the `"scripts"` section of `package.json`:
```json
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}
```

### Step 4: Run Deployment
```bash
npm run deploy
```

In GitHub Repository Settings -> Pages, ensure the source is set to the `gh-pages` branch. Your site will be live at:
`https://<your-username>.github.io/your-kohinoor/`

---

## 🔐 4. Demo Mode vs. Real Production Backend Integration

### What is Demo-Only in this build:
* **UTR Verification:** The client checks that the entered UTR conforms to the standard 12-digit Indian UPI Unique Transaction Reference (RRN) format, and executes a simulated verification roundtrip.
* **Disclaimer:** It is clearly labeled:
  `DEMO MODE — Payment verification is simulated`
  It explicitly states that this is a simulated demo and never pretends that a real bank settlement has been confirmed without a backend.

### What is Required for a Real Production Gateway:
1. **Licensed Payment Gateway / Aggregator:**
   Register with an authorized Indian payment aggregator (e.g., Razorpay, Cashfree Payments, PhonePe PG, Paytm PG, or bank merchant API like ICICI EazyPay).
2. **Backend Server API (`/api/create-order`):**
   When the user clicks "GET PREMIUM", the frontend calls your secure backend to create an authorized order with an immutable transaction ID.
3. **Webhook Handler (`/api/webhook/payment`):**
   The payment gateway notifies your server asynchronously when payment is successfully captured. Your backend verifies the cryptographic webhook signature (HMAC-SHA256) to ensure the request genuinely came from the bank/gateway.
4. **Idempotent Database Ledger:**
   Once verified, mark the user account or device token as "PREMIUM_ACTIVE" in a persistent database (e.g., Firestore or PostgreSQL) and ensure a UTR cannot be submitted twice.
